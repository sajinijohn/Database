-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 20, 2020 at 01:53 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `company`
--

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `Employee_ID` int(10) NOT NULL,
  `First_Name` varchar(20) NOT NULL,
  `Last_Name` varchar(20) NOT NULL,
  `Salary` int(8) NOT NULL,
  `Joining_Date` date NOT NULL,
  `Department` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`Employee_ID`, `First_Name`, `Last_Name`, `Salary`, `Joining_Date`, `Department`) VALUES
(1, 'Sajini', 'John', 15000, '2020-01-07', 'IT'),
(2, 'Mariya', 'Joseph', 20000, '2020-01-08', 'IT'),
(3, 'Aswathy', 'M K', 22000, '2020-01-09', 'Technical'),
(4, 'Nimmya', 'T S', 18000, '2020-01-10', 'Marketing'),
(5, 'Beema', 'S', 16000, '2020-01-11', 'Marketing'),
(6, 'Subi mol', 'Chacko', 20000, '2020-01-13', 'Technical'),
(7, 'Ruksana', 'M', 23000, '2020-01-14', 'HR'),
(8, 'Jismy', 'Jose', 32000, '2020-01-15', 'Production'),
(9, 'Irfana', 'A', 25000, '2020-01-16', 'Developer'),
(10, 'Salvishah', 'S', 28000, '2020-01-20', 'Administration'),
(11, 'Laya', 'Rajan', 34000, '2020-01-08', 'Research'),
(12, 'Kukkumol', 'Thomas', 30000, '2020-01-15', 'Administration'),
(13, 'Neeraja', 'K', 28000, '2020-01-14', 'Production'),
(14, 'Veena', 'Raj', 23500, '2020-01-09', 'Developer'),
(15, 'Mohan', 'Kumar', 24000, '2020-01-07', 'IT');

-- --------------------------------------------------------

--
-- Table structure for table `incentives`
--

CREATE TABLE `incentives` (
  `Employee_ID` int(10) NOT NULL,
  `Incentive_Date` date NOT NULL,
  `Incentive_Amount` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `incentives`
--

INSERT INTO `incentives` (`Employee_ID`, `Incentive_Date`, `Incentive_Amount`) VALUES
(5, '2020-01-30', 5000),
(8, '2020-02-19', 8000),
(1, '2020-01-31', 5500),
(13, '2020-02-28', 4000),
(7, '2020-02-21', 6000),
(2, '2020-02-11', 6500),
(15, '2020-03-02', 5800),
(4, '2020-02-17', 4300),
(10, '2020-02-24', 6500),
(12, '2020-02-20', 4600);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
